package com.aguru.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var input: EditText
    private val audioPermission = 101
    private val speechRequest = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(0xFF061426.toInt())
        }
        fun text(s: String, size: Float, color: Int) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        }
        page.addView(text("A GURU", 34f, 0xFF71E2FF.toInt()))
        page.addView(text("YOUR MARATHI AI ASSISTANT", 12f, 0xFFB8D8E8.toInt()))
        status = text("सिस्टम तयार आहे", 16f, 0xFF69DFFF.toInt())
        page.addView(status)
        page.addView(Button(this).apply {
            text = "🎙️ बोला — A GURU ऐकत आहे"
            setOnClickListener { listen() }
        })
        input = EditText(this).apply {
            hint = "आदेश लिहा"; setTextColor(-1); setHintTextColor(0xFF9AB4C4.toInt())
        }
        page.addView(input)
        page.addView(Button(this).apply {
            text = "आदेश पाठवा"; setOnClickListener { command(input.text.toString()) }
        })
        answer = text("नमस्कार सर! मी A GURU आहे.", 19f, -1)
        answer.setPadding(0, 30, 0, 30)
        page.addView(answer)
        page.addView(text("उदाहरणे: वेळ सांग • तारीख सांग • गूगल उघड • यूट्यूब उघड • शोध नोकऱ्या", 14f, 0xFFB8D8E8.toInt()))
        setContentView(ScrollView(this).apply { addView(page) })
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermission)
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("mr", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                tts.setLanguage(Locale("hi", "IN"))
        }
    }

    private fun say(s: String) {
        answer.text = s
        tts.setPitch(0.78f)
        tts.setSpeechRate(0.88f)
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "aguru")
        status.text = "A GURU बोलत आहे..."
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("या फोनमध्ये आवाज ओळखण्याची सेवा उपलब्ध नाही. आदेश टाइप करा."); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermission); return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "A GURU ला आदेश द्या")
        }
        try { startActivityForResult(i, speechRequest) }
        catch (_: Exception) { say("आवाज सेवा सुरू झाली नाही. आदेश टाइप करून पाहा.") }
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            command(words)
        }
    }

    private fun command(raw: String) {
        val q = raw.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) return
        input.setText(raw)
        when {
            q.contains("वेळ") || q.contains("time") ->
                say("आत्ता वेळ " + SimpleDateFormat("h:mm a", Locale("mr", "IN")).format(Date()) + " झाली आहे.")
            q.contains("तारीख") || q.contains("दिनांक") ->
                say("आज " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale("mr", "IN")).format(Date()) + " आहे.")
            q.contains("गूगल") || q.contains("google") -> { say("गूगल उघडत आहे."); open("https://www.google.com") }
            q.contains("यूट्यूब") || q.contains("youtube") -> { say("यूट्यूब उघडत आहे."); open("https://www.youtube.com") }
            q.startsWith("शोध ") -> {
                val term = raw.substringAfter("शोध ").trim()
                say("$term यासाठी शोधत आहे.")
                open("https://www.google.com/search?q=" + android.net.Uri.encode(term))
            }
            q.contains("नमस्कार") || q.contains("हॅलो") -> say("नमस्कार सर! मी A GURU. सांगा, काय मदत करू?")
            else -> say("हा आदेश पहिल्या आवृत्तीत उपलब्ध नाही. वेळ सांग, तारीख सांग, गूगल उघड किंवा शोध असे आदेश वापरा.")
        }
        status.text = "आदेश पूर्ण."
    }

    private fun open(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
        catch (_: Exception) { say("लिंक उघडता आली नाही.") }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
