# A GURU — Android मराठी सहाय्यक (v1.0 source)

ही Android प्रोजेक्टची source फाइल आहे. **ही APK नाही.**

## सध्या उपलब्ध
- मराठी मजकूर आदेश लिहून पाठवणे
- फोनच्या Speech Recognizer मधून मराठी आवाजाने आदेश देणे (फोनमधील Google/Speech सेवा आणि इंटरनेट/भाषा पॅकवर अवलंबून)
- Android Text-to-Speech मधून उत्तर ऐकणे (मराठी आवाज उपलब्ध नसल्यास हिंदी fallback)
- वेळ आणि तारीख सांगणे
- Google, YouTube उघडणे
- `शोध <शब्द>` या आदेशाने Google वर शोधणे

## अजून उपलब्ध नाही
- ChatGPT/Gemini सारखा खरा AI संवाद
- "Hey A GURU" सारखा सतत ऐकणारा wake-word
- पूर्ण offline speech recognition
- स्वतःहून APK डाउनलोड/इंस्टॉल करणारे auto-update. Android मध्ये अपडेटसाठी वापरकर्त्याची संमती आवश्यक असते.

## प्रोजेक्ट माहिती
- App label: A GURU
- Application ID: `com.aguru.assistant`
- Version: `1.0` (versionCode 1)
- Minimum Android: 8.0 (API 26)
- Compile SDK: 35
- Android Gradle Plugin: 8.7.3
- Kotlin plugin: 2.0.21

## APK कशी तयार करायची
1. Android Studio किंवा Android Gradle Plugin 8.7.3 आणि SDK 35 सपोर्ट करणाऱ्या IDE मध्ये `AGURU_Android_Project` फोल्डर उघडा.
2. Gradle Sync पूर्ण होऊ द्या.
3. Build → Build Bundle(s) / APK(s) → Build APK(s) निवडा.
4. Debug APK येथे मिळेल: `app/build/outputs/apk/debug/app-debug.apk`

या ZIP मध्ये Gradle Wrapper JAR आणि Android SDK समाविष्ट नाहीत. त्यामुळे IDE मध्ये Gradle/SDK उपलब्ध असणे गरजेचे आहे.

## परवानग्या
- `RECORD_AUDIO`: आवाजाने आदेश घेण्यासाठी
- `INTERNET`: बाह्य Google/YouTube लिंक व फोनच्या speech सेवा वापरण्यासाठी

पहिल्यांदा मायक्रोफोन परवानगी मागितली जाईल. परवानगी न दिल्यास टाइप करून आदेश देता येतात.
